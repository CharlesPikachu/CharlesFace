<!--
    Please provide as much as detail and example as you can.
    You can add screenshots if appropriate.
-->

- **OS:**
- **PyQt version:**
